import React from 'react';

function MyChild(props) {
    return (
        <div>
            <h2>{props.user}</h2>
        </div>
    );
}

export default MyChild;